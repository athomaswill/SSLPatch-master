#import <corecrypto/ccn.h>

#define ccec_full_ctx_decl(size, name) \
	long name ## _1; \
	long name ## _2; \
	char name ## _3[292]

